<?php 
include 'db.php';
$id=$_SESSION['id']; 
$uid=$_SESSION['id'];

$sql = "SELECT * FROM users WHERE id='$uid'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $mno=$row['mobile'];
        $gen=$row['gender'];
        $pass=password_verify($password,$row['password']);
        $unm=$row['username'];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="CSS/home.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <style>
        .profile-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        .profile-container h2 {
            margin-bottom: 20px;
        }
        .profile-info {
            text-align: left;
        }
        .profile-info p {
            margin: 10px 0;
            font-size: 16px;
        }
        .label {
            font-weight: bold;
            color: #333;
        }
        .edit-button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
        }
        .edit-button:hover {
            background-color: #0056b3;
        }
        .cen{
            display:flex;
            justify-content:center;
            align-item:center;
        }
    </style>
</head>
<body>
<div class="cen">
    <div class="profile-container">
        <h2>User Profile</h2>
        <form action="#">
        <div class="profile-info">
            <p><span class="label">ID:<?php echo "<input type='text' value='$id'>" ?></span> </p>
            <p><span class="label">Username:<?php echo "<input type='text' value='$unm'>" ?></span></p>
            <p><span class="label">Password:<?php echo "<input type='text' value='$pass'>" ?></span></p>
            <p><span class="label">Mobile:<?php echo "<input type='text' value='$mno'>" ?></span></p>
            <p><span class="label">Gender:<?php echo "<input type='option'value='$gen'>" ?></span></p>
        </div>
    </form>
        <button class="edit-button">Edit Profile</button>
    </div>
    </cen>
</body>
</html>